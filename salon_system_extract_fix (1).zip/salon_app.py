import tkinter as tk
from tkinter import ttk,messagebox,filedialog
import sqlite3, hashlib, secrets, csv, webbrowser, tempfile
from pathlib import Path
from datetime import date,datetime

ROOT=Path(__file__).resolve().parent
(ROOT/"salon_data").mkdir(exist_ok=True)
DB=ROOT/"salon_data"/"salon.db"
def hp(p,s=None):
 s=s or secrets.token_hex(16)
 return s,hashlib.pbkdf2_hmac("sha256",p.encode(),bytes.fromhex(s),180000).hex()
def ok(p,s,h): return secrets.compare_digest(hp(p,s)[1],h)
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title("Salon Management System");self.geometry("1100x700");self.minsize(900,560)
  self.c=sqlite3.connect(DB);self.c.row_factory=sqlite3.Row;self.c.execute("PRAGMA foreign_keys=ON")
  self.c.executescript("""
  CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,salt TEXT,hash TEXT,role TEXT);
  CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY,name TEXT,phone TEXT,notes TEXT,created TEXT);
  CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,code TEXT UNIQUE,name TEXT,category TEXT,qty INTEGER,alert INTEGER,cost REAL,price REAL,supplier TEXT,updated TEXT);
  CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY,client INTEGER REFERENCES clients(id),day TEXT,time TEXT,service TEXT,price REAL,status TEXT,notes TEXT);
  CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY,day TEXT,client INTEGER REFERENCES clients(id),kind TEXT,item TEXT,qty INTEGER,unit REAL,total REAL,payment TEXT,by TEXT);
  CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY,product INTEGER REFERENCES products(id),day TEXT,change_qty INTEGER NOT NULL,reason TEXT NOT NULL,notes TEXT NOT NULL DEFAULT '',by TEXT NOT NULL);
  """)
  if not self.c.execute("SELECT id FROM users").fetchone():
   s,h=hp("SalonStart123!");self.c.execute("INSERT INTO users(username,salt,hash,role) VALUES(?,?,?,?)",("admin",s,h,"admin"));self.c.commit()
  self.user=None;self.login();self.protocol("WM_DELETE_WINDOW",self.close)
 def q(self,s,a=()):return self.c.execute(s,a).fetchall()
 def run(self,s,a=()):self.c.execute(s,a);self.c.commit()
 def clear(self):
  for w in self.winfo_children():w.destroy()
 def login(self):
  self.clear();f=ttk.Frame(self,padding=30);f.pack(expand=True)
  ttk.Label(f,text="SALON MANAGEMENT SYSTEM",font=("Segoe UI",18,"bold")).pack(pady=10)
  self.un=tk.StringVar();self.pw=tk.StringVar()
  for label,var,show in [("Username",self.un,""),("Password",self.pw,"•")]:
   r=ttk.Frame(f);r.pack(pady=5);ttk.Label(r,text=label,width=12).pack(side="left");ttk.Entry(r,textvariable=var,show=show,width=28).pack(side="left")
  ttk.Button(f,text="Sign in",command=self.signin).pack(fill="x",pady=10)
  ttk.Label(f,text="Initial login: admin / SalonStart123! — change immediately.",foreground="#9a451b").pack()
  self.bind("<Return>",lambda e:self.signin())
 def signin(self):
  r=self.q("SELECT * FROM users WHERE username=?",(self.un.get().strip(),))
  if not r or not ok(self.pw.get(),r[0]["salt"],r[0]["hash"]):messagebox.showerror("Login failed","Incorrect username or password");return
  self.user=dict(r[0]);self.unbind("<Return>");self.main()
 def main(self):
  self.clear();top=ttk.Frame(self,padding=10);top.pack(fill="x")
  ttk.Label(top,text="Salon Management",font=("Segoe UI",18,"bold")).pack(side="left")
  ttk.Label(top,text=f'{self.user["username"]} ({self.user["role"]})').pack(side="right")
  ttk.Button(top,text="Log out",command=self.login).pack(side="right",padx=10)
  self.nb=ttk.Notebook(self);self.nb.pack(fill="both",expand=True,padx=10,pady=10)
  self.tabs={}
  for name in ["Dashboard","Inventory","Clients","Appointments","Sales","Reports / Settings"]:
   p=ttk.Frame(self.nb,padding=12);self.nb.add(p,text=name);self.tabs[name]=p
  self.dashboard();self.inventory();self.clients();self.appointments();self.sales();self.reports()
 def tree(self,p,cols):
  fr=ttk.Frame(p);fr.pack(fill="both",expand=True,pady=8);t=ttk.Treeview(fr,columns=[x[0] for x in cols],show="headings")
  y=ttk.Scrollbar(fr,orient="vertical",command=t.yview);t.configure(yscrollcommand=y.set);t.grid(row=0,column=0,sticky="nsew");y.grid(row=0,column=1,sticky="ns");fr.rowconfigure(0,weight=1);fr.columnconfigure(0,weight=1)
  for k,l,w in cols:t.heading(k,text=l);t.column(k,width=w)
  return t
 def fill(self,t,sql,args=()):
  t.delete(*t.get_children())
  for r in self.q(sql,args):t.insert("","end",values=tuple(r))
 def dashboard(self):
  p=self.tabs["Dashboard"];ttk.Label(p,text="Business dashboard",font=("Segoe UI",17,"bold")).pack(anchor="w")
  self.dash=ttk.Label(p,text="",font=("Segoe UI",13));self.dash.pack(anchor="w",pady=10)
  self.low=self.tree(p,[("code","Code",100),("name","Product",250),("qty","Stock",90),("alert","Reorder at",100)])
  ttk.Button(p,text="Refresh",command=self.refresh).pack(anchor="e");self.refresh()
 def refresh(self):
  vals=[self.q("SELECT COUNT(*) FROM clients")[0][0],self.q("SELECT COUNT(*) FROM products")[0][0],self.q("SELECT COUNT(*) FROM products WHERE qty<=alert")[0][0],self.q("SELECT COUNT(*) FROM appointments WHERE day=? AND status='Booked'",(date.today().isoformat(),))[0][0],self.q("SELECT COALESCE(SUM(total),0) FROM sales WHERE day=?",(date.today().isoformat(),))[0][0]]
  month_start=date.today().replace(day=1).isoformat()
  month_sales=self.q("SELECT COALESCE(SUM(total),0) FROM sales WHERE day>=?",(month_start,))[0][0]
  self.dash.config(text=f"Clients: {vals[0]}    Products: {vals[1]}    Low stock: {vals[2]}    Appointments today: {vals[3]}    Sales today: KSh {vals[4]:,.2f}    Month-to-date: KSh {month_sales:,.2f}")
  self.fill(self.low,"SELECT code,name,qty,alert FROM products WHERE qty<=alert ORDER BY qty,name")
  self.refresh_products();self.refresh_clients();self.refresh_appts();self.refresh_sales()
 def inventory(self):
  p=self.tabs["Inventory"];ttk.Label(p,text="Inventory",font=("Segoe UI",17,"bold")).pack(anchor="w")
  bar=ttk.Frame(p);bar.pack(fill="x");self.ps=tk.StringVar();ttk.Label(bar,text="Search").pack(side="left");e=ttk.Entry(bar,textvariable=self.ps);e.pack(side="left",padx=5);e.bind("<KeyRelease>",lambda ev:self.refresh_products())
  ttk.Button(bar,text="Add product",command=self.product_form).pack(side="left",padx=5);ttk.Button(bar,text="Receive stock",command=self.receive_stock).pack(side="left",padx=5);ttk.Button(bar,text="Edit selected",command=self.edit_product).pack(side="left",padx=5);ttk.Button(bar,text="Stock history",command=self.stock_history).pack(side="left")
  self.pt=self.tree(p,[("code","Code",90),("name","Product",200),("category","Category",120),("qty","Stock",70),("alert","Alert",70),("cost","Cost KSh",90),("price","Price KSh",90),("supplier","Supplier",140),("updated","Updated",100)])
  self.refresh_products()
 def refresh_products(self):
  if hasattr(self,"pt"):
   s="%"+self.ps.get().strip()+"%";self.fill(self.pt,"SELECT code,name,category,qty,alert,printf('%.2f',cost),printf('%.2f',price),supplier,updated FROM products WHERE name LIKE ? OR code LIKE ? OR category LIKE ? ORDER BY name",(s,s,s))
 def product_form(self,old=None):
  self.form("Product / stock",[("Code *","code",""),("Name *","name",""),("Category","category","Beauty products"),("Quantity on hand","qty","0"),("Low-stock alert level","alert","3"),("Unit cost (KES)","cost","0"),("Selling price (KES)","price","0"),("Supplier","supplier","")],old,
   lambda d,old:self.run("UPDATE products SET code=?,name=?,category=?,qty=?,alert=?,cost=?,price=?,supplier=?,updated=? WHERE id=?",(d["code"],d["name"],d["category"],int(d["qty"]),int(d["alert"]),float(d["cost"]),float(d["price"]),d["supplier"],date.today().isoformat(),old["id"])) if old else self.run("INSERT INTO products(code,name,category,qty,alert,cost,price,supplier,updated) VALUES(?,?,?,?,?,?,?,?,?)",(d["code"],d["name"],d["category"],int(d["qty"]),int(d["alert"]),float(d["cost"]),float(d["price"]),d["supplier"],date.today().isoformat())))
 def receive_stock(self):
  products=self.q("SELECT * FROM products ORDER BY name")
  if not products:
   messagebox.showinfo("Add a product first","Register a product before receiving stock.");return
  win=tk.Toplevel(self);win.title("Receive stock");win.transient(self);win.grab_set();f=ttk.Frame(win,padding=15);f.pack()
  labels={f'{r["code"]} | {r["name"]} (current stock {r["qty"]})':dict(r) for r in products}
  pv=tk.StringVar(value=list(labels)[0]);ttk.Label(f,text="Product").grid(row=0,column=0,sticky="w",pady=5);ttk.Combobox(f,textvariable=pv,values=list(labels),state="readonly",width=42).grid(row=0,column=1,padx=8,pady=5)
  qty=tk.StringVar(value="1");notes=tk.StringVar(value="Supplier delivery")
  ttk.Label(f,text="Quantity received").grid(row=1,column=0,sticky="w",pady=5);ttk.Entry(f,textvariable=qty,width=20).grid(row=1,column=1,sticky="w",padx=8,pady=5)
  ttk.Label(f,text="Supplier / invoice note").grid(row=2,column=0,sticky="w",pady=5);ttk.Entry(f,textvariable=notes,width=42).grid(row=2,column=1,padx=8,pady=5)
  def save():
   try:n=int(qty.get());assert n>0
   except:messagebox.showerror("Invalid quantity","Enter a whole number greater than zero.",parent=win);return
   prod=labels[pv.get()]
   self.run("UPDATE products SET qty=qty+?,updated=? WHERE id=?",(n,date.today().isoformat(),prod["id"]))
   self.run("INSERT INTO stock_movements(product,day,change_qty,reason,notes,by) VALUES(?,?,?,?,?,?)",(prod["id"],date.today().isoformat(),n,"Stock received",notes.get().strip(),self.user["username"]))
   win.destroy();self.refresh()
  ttk.Button(f,text="Receive stock",command=save).grid(row=3,column=0,columnspan=2,sticky="ew",pady=10)
 def stock_history(self):
  win=tk.Toplevel(self);win.title("Stock movement history");win.geometry("850x420")
  t=self.tree(win,[("day","Date",100),("code","Code",90),("name","Product",180),("change","Change (+/-)",100),("reason","Reason",130),("notes","Notes",180),("by","Recorded by",100)])
  self.fill(t,"SELECT m.day,p.code,p.name,m.change_qty,m.reason,m.notes,m.by FROM stock_movements m JOIN products p ON p.id=m.product ORDER BY m.id DESC LIMIT 500")
 def edit_product(self):
  s=self.pt.selection()
  if not s:messagebox.showinfo("Select","Select a product first.");return
  self.product_form(dict(self.q("SELECT * FROM products WHERE code=?",(self.pt.item(s[0],"values")[0],))[0]))
 def form(self,title,fields,old,savefn):
  win=tk.Toplevel(self);win.title(title);win.transient(self);win.grab_set();f=ttk.Frame(win,padding=15);f.pack();vars={}
  for i,(label,key,default) in enumerate(fields):
   ttk.Label(f,text=label).grid(row=i,column=0,sticky="w",pady=4);v=tk.StringVar(value=str((old or {}).get(key,default) or ""));vars[key]=v;ttk.Entry(f,textvariable=v,width=34).grid(row=i,column=1,padx=8,pady=4)
  def save():
   d={k:v.get().strip() for k,v in vars.items()}
   try:savefn(d,old)
   except (ValueError,sqlite3.IntegrityError) as e:messagebox.showerror("Could not save","Check required fields, numbers, and unique codes.\n"+str(e),parent=win);return
   if any(k.endswith("*") for k in []):pass
   win.destroy();self.refresh()
  ttk.Button(f,text="Save",command=save).grid(row=len(fields),column=0,columnspan=2,sticky="ew",pady=10)
 def clients(self):
  p=self.tabs["Clients"];ttk.Label(p,text="Clients",font=("Segoe UI",17,"bold")).pack(anchor="w");ttk.Button(p,text="Add client",command=self.client_form).pack(anchor="w",pady=5)
  self.ct=self.tree(p,[("name","Name",230),("phone","Phone",150),("created","Registered",110),("notes","Notes",400)]);self.refresh_clients()
 def client_form(self):
  self.form("Add client",[("Name *","name",""),("Phone","phone",""),("Notes","notes","")],None,lambda d,o:self.run("INSERT INTO clients(name,phone,notes,created) VALUES(?,?,?,?)",(d["name"] or (_ for _ in ()).throw(ValueError("Name required")),d["phone"],d["notes"],date.today().isoformat())))
 def refresh_clients(self):
  if hasattr(self,"ct"):self.fill(self.ct,"SELECT name,phone,created,notes FROM clients ORDER BY name")
 def clientmap(self):return {f'{r["name"]} | {r["phone"]}':r["id"] for r in self.q("SELECT * FROM clients ORDER BY name")}
 def appointments(self):
  p=self.tabs["Appointments"];ttk.Label(p,text="Appointments",font=("Segoe UI",17,"bold")).pack(anchor="w");ttk.Button(p,text="Book appointment",command=self.appt_form).pack(anchor="w",pady=5)
  self.at=self.tree(p,[("day","Date",110),("time","Time",90),("client","Client",180),("service","Service",180),("price","Price KSh",100),("status","Status",100),("notes","Notes",200)])
  row=ttk.Frame(p);row.pack(fill="x");ttk.Button(row,text="Mark selected completed",command=lambda:self.status("Completed")).pack(side="left");ttk.Button(row,text="Cancel selected",command=lambda:self.status("Cancelled")).pack(side="left",padx=5);self.refresh_appts()
 def appt_form(self):
  cmap=self.clientmap()
  if not cmap:messagebox.showinfo("Register client","Add a client first.");return
  win=tk.Toplevel(self);win.title("Book appointment");win.transient(self);win.grab_set();f=ttk.Frame(win,padding=15);f.pack()
  cv=tk.StringVar(value=list(cmap)[0]);ttk.Label(f,text="Client").grid(row=0,column=0);ttk.Combobox(f,textvariable=cv,values=list(cmap),state="readonly",width=30).grid(row=0,column=1,pady=4)
  specs=[("Date YYYY-MM-DD",date.today().isoformat()),("Time","10:00"),("Service","Manicure"),("Price KES","0"),("Notes","")];vs=[]
  for i,(lab,val) in enumerate(specs,1):
   ttk.Label(f,text=lab).grid(row=i,column=0,sticky="w");v=tk.StringVar(value=val);vs.append(v);
   if lab=="Service": ttk.Combobox(f,textvariable=v,values=["Manicure","Pedicure","Gel nails","Acrylic nails","Nail art","Makeup","Facial","Eyebrow shaping","Eyelash extensions","Lash lift","Waxing","Massage","Other beauty service"],width=31).grid(row=i,column=1,pady=4)
   else: ttk.Entry(f,textvariable=v,width=33).grid(row=i,column=1,pady=4)
  def save():
   try:datetime.strptime(vs[0].get(),"%Y-%m-%d");price=float(vs[3].get());assert price>=0
   except:messagebox.showerror("Invalid","Check date and price.",parent=win);return
   self.run("INSERT INTO appointments(client,day,time,service,price,status,notes) VALUES(?,?,?,?,?,'Booked',?)",(cmap[cv.get()],vs[0].get(),vs[1].get(),vs[2].get(),price,vs[4].get()));win.destroy();self.refresh()
  ttk.Button(f,text="Save appointment",command=save).grid(row=6,column=0,columnspan=2,sticky="ew",pady=8)
 def refresh_appts(self):
  if hasattr(self,"at"):self.fill(self.at,"SELECT a.day,a.time,c.name,a.service,printf('%.2f',a.price),a.status,a.notes FROM appointments a JOIN clients c ON c.id=a.client ORDER BY a.day DESC,a.time")
 def status(self,status):
  s=self.at.selection()
  if not s:return
  v=self.at.item(s[0],"values");r=self.q("SELECT a.id FROM appointments a JOIN clients c ON c.id=a.client WHERE a.day=? AND a.time=? AND c.name=? AND a.service=? ORDER BY a.id DESC LIMIT 1",(v[0],v[1],v[2],v[3]))
  if r:self.run("UPDATE appointments SET status=? WHERE id=?",(status,r[0]["id"]));self.refresh()
 def sales(self):
  p=self.tabs["Sales"];ttk.Label(p,text="Record sale",font=("Segoe UI",17,"bold")).pack(anchor="w");ttk.Button(p,text="New sale",command=self.sale_form).pack(anchor="w",pady=5)
  self.st=self.tree(p,[("day","Date",100),("client","Client",180),("kind","Type",90),("item","Item/service",200),("qty","Qty",60),("total","Total KSh",100),("payment","Payment",100),("by","Recorded by",100)]);self.refresh_sales()
 def sale_form(self):
  clients=self.clientmap();products=self.q("SELECT * FROM products ORDER BY name")
  win=tk.Toplevel(self);win.title("Record sale");win.transient(self);win.grab_set();f=ttk.Frame(win,padding=15);f.pack()
  cvals=["Walk-in"]+list(clients);cv=tk.StringVar(value=cvals[0]);ttk.Label(f,text="Client").grid(row=0,column=0,sticky="w");ttk.Combobox(f,textvariable=cv,values=cvals,state="readonly",width=45).grid(row=0,column=1,pady=4)
  kind=tk.StringVar(value="Service");ttk.Label(f,text="Type").grid(row=1,column=0,sticky="w");ttk.Combobox(f,textvariable=kind,values=["Service","Product"],state="readonly",width=20).grid(row=1,column=1,sticky="w",pady=4)
  pmap={f'{r["code"]} | {r["name"]} (stock {r["qty"]})':dict(r) for r in products};pv=tk.StringVar(value=list(pmap)[0] if pmap else "No products")
  ttk.Label(f,text="Product (if product sale)").grid(row=2,column=0,sticky="w");ttk.Combobox(f,textvariable=pv,values=list(pmap) or ["No products"],state="readonly",width=45).grid(row=2,column=1,pady=4)
  desc=tk.StringVar(value="Manicure");qty=tk.StringVar(value="1");price=tk.StringVar(value="0");pay=tk.StringVar(value="Cash")
  for i,(lab,v) in enumerate([("Description/service",desc),("Quantity",qty),("Unit price KES",price)],3):
   ttk.Label(f,text=lab).grid(row=i,column=0,sticky="w");
   if lab=="Description/service": ttk.Combobox(f,textvariable=v,values=["Manicure","Pedicure","Gel nails","Acrylic nails","Nail art","Makeup","Facial","Eyebrow shaping","Eyelash extensions","Lash lift","Waxing","Massage","Other beauty service"],width=32).grid(row=i,column=1,sticky="w",pady=4)
   else: ttk.Entry(f,textvariable=v,width=35).grid(row=i,column=1,sticky="w",pady=4)
  ttk.Label(f,text="Payment method").grid(row=6,column=0,sticky="w");ttk.Combobox(f,textvariable=pay,values=["M-Pesa","Cash"],state="readonly",width=20).grid(row=6,column=1,sticky="w",pady=4)
  def productselect(*_):
   if kind.get()=="Product" and pv.get() in pmap:desc.set(pmap[pv.get()]["name"]);price.set(str(pmap[pv.get()]["price"]))
  pv.trace_add("write",productselect);kind.trace_add("write",productselect)
  def save():
   try:q=int(qty.get());pr=float(price.get());assert q>0 and pr>=0
   except:messagebox.showerror("Invalid","Quantity must be positive and price non-negative.",parent=win);return
   pid=None
   if kind.get()=="Product":
    if pv.get() not in pmap:messagebox.showerror("Select product","Add/select a product first.",parent=win);return
    prod=pmap[pv.get()];pid=prod["id"]
    if prod["qty"]<q:messagebox.showerror("Low stock",f'Only {prod["qty"]} available.',parent=win);return
   client=clients.get(cv.get());total=q*pr
   self.run("INSERT INTO sales(day,client,kind,item,qty,unit,total,payment,by) VALUES(?,?,?,?,?,?,?,?,?)",(date.today().isoformat(),client,kind.get(),desc.get(),q,pr,total,pay.get(),self.user["username"]))
   if pid:
    self.run("UPDATE products SET qty=qty-?,updated=? WHERE id=?",(q,date.today().isoformat(),pid))
    self.run("INSERT INTO stock_movements(product,day,change_qty,reason,notes,by) VALUES(?,?,?,?,?,?)",(pid,date.today().isoformat(),-q,"Product sale",f"Sale: {desc.get().strip()}",self.user["username"]))
   win.destroy();self.refresh()
  ttk.Button(f,text="Save sale",command=save).grid(row=7,column=0,columnspan=2,sticky="ew",pady=10)
 def refresh_sales(self):
  if hasattr(self,"st"):self.fill(self.st,"SELECT s.day,COALESCE(c.name,'Walk-in'),s.kind,s.item,s.qty,printf('%.2f',s.total),s.payment,s.by FROM sales s LEFT JOIN clients c ON c.id=s.client ORDER BY s.id DESC LIMIT 500")
 def reports(self):
  p=self.tabs["Reports / Settings"];ttk.Label(p,text="Reports & Settings",font=("Segoe UI",17,"bold")).pack(anchor="w")
  row=ttk.Frame(p);row.pack(anchor="w",pady=8)
  ttk.Button(row,text="Export CSV files",command=self.export).pack(side="left",padx=4);ttk.Button(row,text="Print sales report",command=self.print_report).pack(side="left",padx=4);ttk.Button(row,text="Back up database",command=self.backup).pack(side="left",padx=4);ttk.Button(row,text="Change password",command=self.change_password).pack(side="left",padx=4)
  ttk.Label(p,text="CSV files can be opened in Excel. Printing opens a browser report; press Ctrl+P.").pack(anchor="w",pady=12)
 def export(self):
  folder=filedialog.askdirectory(title="Choose export folder")
  if not folder:return
  sets={"products.csv":"SELECT code,name,category,qty,alert,cost,price,supplier,updated FROM products","stock_movements.csv":"SELECT m.day,p.code,p.name,m.change_qty,m.reason,m.notes,m.by FROM stock_movements m JOIN products p ON p.id=m.product ORDER BY m.id DESC","clients.csv":"SELECT name,phone,notes,created FROM clients","appointments.csv":"SELECT a.day,a.time,c.name,a.service,a.price,a.status,a.notes FROM appointments a JOIN clients c ON c.id=a.client","sales.csv":"SELECT s.day,COALESCE(c.name,'Walk-in') client,s.kind,s.item,s.qty,s.unit,s.total,s.payment,s.by FROM sales s LEFT JOIN clients c ON c.id=s.client"}
  try:
   for fn,sql in sets.items():
    rows=self.q(sql)
    with open(Path(folder)/fn,"w",newline="",encoding="utf-8-sig") as f:
     w=csv.writer(f)
     if rows:w.writerow(rows[0].keys());w.writerows([tuple(r) for r in rows])
     else:w.writerow(["No records"])
   messagebox.showinfo("Exported","CSV reports saved.")
  except Exception as e:messagebox.showerror("Export failed",str(e))
 def print_report(self):
  rows=self.q("SELECT s.day,COALESCE(c.name,'Walk-in') client,s.kind,s.item,s.qty,s.total,s.payment FROM sales s LEFT JOIN clients c ON c.id=s.client ORDER BY s.id DESC")
  esc=lambda x:str(x).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
  total=sum(r["total"] for r in rows)
  h="<html><meta charset='utf-8'><title>Salon Sales</title><body style='font-family:Arial'><h1>Salon Sales Report</h1><p>Generated "+date.today().isoformat()+"</p><table border='1' cellpadding='6'><tr><th>Date</th><th>Client</th><th>Type</th><th>Item</th><th>Qty</th><th>Total KES</th><th>Payment</th></tr>"
  for r in rows:h+="<tr>"+"".join("<td>"+esc(r[k])+"</td>" for k in ["day","client","kind","item","qty","total","payment"])+"</tr>"
  h+=f"</table><h3>Recorded total: KSh {total:,.2f}</h3><button onclick='window.print()'>Print</button></body></html>"
  path=Path(tempfile.gettempdir())/"salon_report.html";path.write_text(h,encoding="utf-8");webbrowser.open(path.as_uri())
 def backup(self):
  p=filedialog.asksaveasfilename(defaultextension=".db",initialfile="salon_backup_"+date.today().strftime("%Y%m%d")+".db",filetypes=[("Database","*.db")])
  if p:
   with sqlite3.connect(p) as dest:self.c.backup(dest)
   messagebox.showinfo("Backup","Database backup saved. Keep it somewhere secure.")
 def change_password(self):
  win=tk.Toplevel(self);win.title("Change password");f=ttk.Frame(win,padding=15);f.pack();vs=[tk.StringVar() for _ in range(3)]
  for i,(lab,v) in enumerate(zip(["Current password","New password (10+ characters)","Confirm new password"],vs)):
   ttk.Label(f,text=lab).grid(row=i,column=0,sticky="w",pady=5);ttk.Entry(f,textvariable=v,show="•",width=28).grid(row=i,column=1,padx=7,pady=5)
  def save():
   r=self.q("SELECT * FROM users WHERE id=?",(self.user["id"],))[0]
   if not ok(vs[0].get(),r["salt"],r["hash"]):messagebox.showerror("Error","Current password is wrong.",parent=win);return
   if len(vs[1].get())<10 or vs[1].get()!=vs[2].get():messagebox.showerror("Error","New passwords must match and be 10+ characters.",parent=win);return
   s,h=hp(vs[1].get());self.run("UPDATE users SET salt=?,hash=? WHERE id=?",(s,h,self.user["id"]));win.destroy();messagebox.showinfo("Done","Password changed.")
  ttk.Button(f,text="Save password",command=save).grid(row=3,column=0,columnspan=2,sticky="ew",pady=8)
 def close(self):
  self.c.close();self.destroy()
if __name__=="__main__":App().mainloop()
