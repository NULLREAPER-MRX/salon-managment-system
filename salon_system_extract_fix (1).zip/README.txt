MOTHER'S BEAUTY SALON MANAGEMENT SYSTEM
=======================================
Windows 10/11 desktop starter app. Uses KSh and is configured for an owner-operated beauty salon accepting M-Pesa and cash.

RUN
1. Extract this ZIP to a folder.
2. Install Python 3 from https://www.python.org/downloads/windows/ if needed. Tick "Add Python to PATH" during installation.
3. Double-click run_salon.bat.
4. Initial login: admin / SalonStart123!
5. Change the password immediately in Reports / Settings.

FEATURES
- Dashboard: clients, products, low stock, appointments today, today's sales and month-to-date sales.
- Beauty product inventory with quantity, reorder alert, cost, selling price and supplier.
- Receive stock separately and keep a stock movement history (receipts and product sales).
- Client records and appointments with beauty service suggestions (manicure, pedicure, gel nails, makeup, facials, brows, lashes, waxing, etc.).
- Record service and product sales; product sales reduce inventory automatically.
- Payment options configured for M-Pesa and cash.
- CSV exports, printable sales report, database backup and password change.

DATA / SAFETY
- Database is stored in salon_data/salon.db beside the application.
- This is a Python app, not a packaged EXE. It works locally on one computer; do not put the SQLite database in a shared network folder.
- The database is not encrypted. Restrict access to the Windows account and store backups securely.
- Test with sample records first. Sales totals depend on accurate data entry and are not a tax/accounting statement.
- Stock history records movements made after this customized version is run; old stock quantities will not have historical movement records.
